CREATE FUNCTION test_test_mek
  RETURN VARCHAR2
AS LANGUAGE JAVA NAME 'ru.sigma.it.Hello.world () return java.lang.String';
/
