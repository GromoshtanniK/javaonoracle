CREATE PROCEDURE simple_test
AS LANGUAGE JAVA
NAME 'ru.sigma.it.Hello.send_test_message ()';
/
