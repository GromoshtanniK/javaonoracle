CREATE FUNCTION get_java_property(prop IN VARCHAR2)
  RETURN VARCHAR2 IS
LANGUAGE JAVA NAME 'java.lang.System.getProperty(java.lang.String) return java.lang.String';
/
